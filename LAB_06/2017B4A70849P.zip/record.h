
typedef struct record{
  char name[10];
  float cgpa;
}rec;

typedef rec Element;
