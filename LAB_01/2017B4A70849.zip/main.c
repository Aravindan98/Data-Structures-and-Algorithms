/***********file:   main.c *********/
#include <stdio.h>
#include "seqListOps.h"
int initialize_elements(JobList);
int main(void)
{
 int i; int size;
 JobList list;
 size = initialize_elements (list);
 printf("\n\n The Jobs waiting on CPU: \n\n");
 printJobList(list, size);
 printf("\n\n");
 sortJobList(list, size);
 printf("\n\nPOST SORTING\n\n");
 printJobList(list, size);
 return 0;
}
 
