#include<stdbool.h>
#include "linkedlist.h"
#include<stdio.h>

extern bool testCyclic(linkedList* Ls);
