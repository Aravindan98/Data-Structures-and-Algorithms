extern void* myalloc(int space_size);
extern void myfree(void* p);
extern long int total_space_allocated;
